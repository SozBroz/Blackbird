''' Implements 'systems' emulation for Kako. '''

from kako.simulation.system import linux
