''' Kako - Manifest driven IoT honeypots. '''

from kako import config
from kako import messaging
from kako import processor
from kako import simulation

__version__ = '0.2.0'
