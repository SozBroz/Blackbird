''' Implements Kako messaging. '''

from kako.messaging import capture
