''' Implements Kako results processors. '''

from kako.processor import sns
from kako.processor import file
